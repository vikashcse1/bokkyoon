const { Schema, model } = require("mongoose");

const adminBookings = new Schema(
  {
    userName:{
      type: String,
    },
    driverName: {
      type: String,
    },
    source: {
      type: String,
    },
    destination:{
        type:String,
    }

  }
);

module.exports = model("adminBookings", adminBookings);
