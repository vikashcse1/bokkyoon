const { Schema, model } = require("mongoose");

const carType  = new Schema(
  {
    type:{
      type:String
    },
    farePerKm:{
      type: Number,
      required: true
    },
    capacity:{
        type: Number
    }
  }
);

module.exports = model("carType", carType);
