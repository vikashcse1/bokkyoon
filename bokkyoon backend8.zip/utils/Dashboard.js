const User = require("../models/User");
const bcrypt = require("bcryptjs");

/**
 * @DESC To register the user (ADMIN, SUPER_ADMIN, USER)
 */
const addUserFromDashboard=async(req,res,profile_pic)=>{

    try {
      // validate the email
      let emailNotRegistered = await validatePhone(req.body.phone);
      if (!emailNotRegistered) {
        return res.status(200).json({
          message: `Phone is already registered.`,
          success: false
        });
      }
  
      // create a new user
      const newUser = new User({
        ...userDets,
        role,
        profile_pic:profile_pic
      });
  
      await newUser.save((err,docs)=>{
        if(!err){
          res.json({
            message:"Registration Successfull.",
            success:true,
            name:docs.name,
            phone:docs.phone,
            email:docs.email
          })
        }
        else{res.send(err)}
      });
  
    } catch (err) {
      // Implement logger function (winston)
      return res.status(200).json({
        message: `Unable to create your account. ${err}`,
        success: false
      });
    }
};

const validatePhone = async phone => {
    let user = await User.findOne({ phone });
    return user ? false : true;
  };

module.exports = {
    addUserFromDashboard
  };