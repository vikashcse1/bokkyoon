const { Schema, model } = require("mongoose");

const adminBookings = new Schema(
  {
    userName:{
      type: String,
    },
    driverName: {
      type: String,
    },
    source: {
      type: String,
    },
    destination:{
        type:String,
    },
    fair:{
      type:Number,
    },
    Vehicle_Registration_Number:{
      type:String,
    },
    bookingid:{
      type:String,
    }

  }
);

module.exports = model("adminBookings", adminBookings);
