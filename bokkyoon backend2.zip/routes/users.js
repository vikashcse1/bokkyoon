const router = require("express").Router();
const multer = require('multer');



//storage startegy
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
      cb(null, 'uploads/');
  },
  filename: function (req, file, cb) {
      cb(null, file.originalname)
  }
});
//file filter
const fileFilter = (req, file, cb) => {
  //reject file
  if (file.mimetype === 'image/jpg' ||file.mimetype === 'image/jpeg'||file.mimetype === 'image/png') {
      cb(null, true);
  } 
  else{
  cb(new Error('Message wrong file type.'), false);
  }
}

const upload = multer({ 
  storage: storage ,
  fileFilter:fileFilter
});
// Bring in the User Registration function
const {
  userAuth,
  userLogin,
  checkRole,
  userRegister,
  serializeUser,
  getUser,
  deleteUser,
  driverRegister,
  getDriver,
  deleteDriver,
  changePassword,
  forgotPassword

} = require("../utils/Auth");

// Users Registeration Route
router.post("/register-user", async (req, res) => {
  await userRegister(req.body, "user", res);
});

router.post("/register-driver",upload.single("profile_pic"), async (req, res) => {
  console.log(req.file)
  profile_pic=String(req.protocol+"://"+req.hostname+":4000/"+req.file.destination+req.file.originalname)
  await driverRegister(req, res,profile_pic);
});

// Admin Registration Route
router.post("/register-admin", async (req, res) => {
  await userRegister(req.body, "admin", res);
});

// Super Admin Registration Route
router.post("/register-super-admin", async (req, res) => {
  await userRegister(req.body, "superadmin", res);
});

// Users Login Route
router.post("/login-user", async (req, res) => {
  await userLogin(req.body, "user", res);
});

// Admin Login Route
router.post("/login-admin", async (req, res) => {
  await userLogin(req.body, "admin", res);
});

// Super Admin Login Route
router.post("/login-super-admin", async (req, res) => {
  await userLogin(req.body, "superadmin", res);
});

// Profile Route
router.get("/profile", userAuth, async (req, res) => {
  return res.json(serializeUser(req.user));
});

router.post('/forgotPassword',(req,res)=>{
  //mo no exist
  //new pass
  forgotPassword(req,res)
})

router.post('/changePassword',(req,res)=>{
  //mo no exist
  //new pass
  changePassword(req,res)
})

// Users Protected Route
router.get(
  "/user-protectd",
  userAuth,
  checkRole(["user"]),
  async (req, res) => {
    return res.json("Hello User");
  }
);

// Admin Protected Route
router.get(
  "/admin-protectd",
  userAuth,
  checkRole(["admin"]),
  async (req, res) => {
    return res.json("Hello Admin");
  }
);

// Super Admin Protected Route
router.get(
  "/super-admin-protectd",
  userAuth,
  checkRole(["superadmin"]),
  async (req, res) => {
    return res.json("Hello Super Admin");
  }
);

// Super Admin Protected Route
router.get(
  "/super-admin-and-admin-protectd",
  userAuth,
  checkRole(["superadmin", "admin"]),
  async (req, res) => {
    return res.json("Super admin and Admin");
  }
);

router.get('/getUser',async (req,res)=>{
  await getUser(res)
})
router.post('/deletUser',async (req,res)=>{
  await deleteUser(req,res)
})

router.get('/getDriver',async (req,res)=>{
  await getDriver(res)
})
router.post('/deletDriver',async (req,res)=>{
  await deleteDriver(req,res)
})


module.exports = router;
