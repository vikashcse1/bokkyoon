const { Schema, model } = require("mongoose");

const driver = new Schema(
  {
    profile_pic:{
      type:String
    },
    phone:{
      type: Number,
      required: true
    },
    email: {
      type: String,
    },
    name: {
      type: String,
      required: true
    },
    password: {
      type: String,
    },
    vehicle_name:{
      type:String,
      require:true
    },
    Vehicle_Registration_Number:{
      type:String,
      require:true
    },
    Vehicle_Image:{
      type:String,
      require:true
    },
    Vehicle_Type:{
      type:String,
    },
    location:{
      type:String,

    },
    fare:{
      type:String
    }
  },
  { timestamps: true }
);

module.exports = model("driver", driver);
