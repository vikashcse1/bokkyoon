const { Schema, model } = require("mongoose");

const vehicles = new Schema(
  {
    source:{
      type:String
    },
    destination:{
      type: String,
    },
    driver_name: {
      type: String,
    },
    Vehicle_Registration_Number:{
      type:String,
    },
    Vehicle_Image:{
      type:String,
    },
    fare:{
      type:String
    }
  }
);

module.exports = model("vehicles", vehicles);
