const { Schema, model } = require("mongoose");

const adminBookings = new Schema(
  {
    userName:{
      type: String,
    },
    userPhone:{type:String},
    driverName: {
      type: String,
    },
    source: {
      type: String,
    },
    destination:{
        type:String,
    },
    fare:{
      type:Number,
    },
    Vehicle_Registration_Number:{
      type:String,
    },
    bookingid:{
      type:String,
    },
    status:{type:String,default:"pending", enum: ["pending", "completed", "canceled","accepted"]}
  }
);

module.exports = model("adminBookings", adminBookings);
