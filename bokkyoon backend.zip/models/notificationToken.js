const { Schema, model } = require("mongoose");

const token = new Schema(
  {
    phone: {
      type: String
    },
    token:{
        type: String
    }
  }
);

module.exports = model("token", token);
