const router = require("express").Router();
const multer = require('multer');
const Bookings = require("../models/Bookings");
const userRides = require("../models/UserRides")
const driver = require("../models/Driver")
const { v4: uuidv4 } = require('uuid');
const fs = require("fs");
const User = require("../models/User");
const faq = require('../models/faq')
const token = require('../models/notificationToken')
const bcrypt = require("bcryptjs");

const today = new Date();

//storage startegy
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'uploads/');
  },
  filename: function (req, file, cb) {
    cb(null, file.originalname)
  }
});
//file filter
const fileFilter = (req, file, cb) => {
  //reject file
  if (file.mimetype === 'image/jpg' || file.mimetype === 'image/jpeg' || file.mimetype === 'image/png') {
    cb(null, true);
  }
  else {
    cb(new Error('Message wrong file type.'), false);
  }
}

const upload = multer({
  storage: storage,
  fileFilter: fileFilter
});
// Bring in the User Registration function
const {
  userAuth,
  userLogin,
  checkRole,
  userRegister,
  serializeUser,
  getUser,
  deleteUser,
  driverRegister,
  getDriver,
  deleteDriver,
  changePassword,
  forgotPassword,
  showNearByCars,
  book,
  notifications,
  getUserNotification

} = require("../utils/Auth");

// Users Registeration Route
router.post("/register-user", async (req, res) => {
  await userRegister(req.body, "user", res);
});

router.post("/register-driver", upload.single("profile_pic"), async (req, res) => {
  console.log(req.file)
  profile_pic = String(req.protocol + "://" + req.hostname + ":4000/" + req.file.destination + req.file.originalname)
  await driverRegister(req, res, profile_pic);
});

// Admin Registration Route
router.post("/register-admin", async (req, res) => {
  await userRegister(req.body, "admin", res);
});

// Super Admin Registration Route
router.post("/register-super-admin", async (req, res) => {
  await userRegister(req.body, "superadmin", res);
});

// Users Login Route
router.post("/login-user", async (req, res) => {
  await userLogin(req.body, "user", res);
});

// Admin Login Route
router.post("/login-admin", async (req, res) => {
  await userLogin(req.body, "admin", res);
});

// Super Admin Login Route
router.post("/login-super-admin", async (req, res) => {
  await userLogin(req.body, "superadmin", res);
});

// Profile Route
router.get("/profile", userAuth, async (req, res) => {
  return res.json(serializeUser(req.user));
});

router.post('/forgotPassword', (req, res) => {
  //mo no exist
  //new pass
  forgotPassword(req, res)
})

router.post('/changePassword', (req, res) => {
  //mo no exist
  //new pass
  changePassword(req, res)
})

// Users Protected Route
router.get(
  "/user-protectd",
  userAuth,
  checkRole(["user"]),
  async (req, res) => {
    return res.json("Hello User");
  }
);

// Admin Protected Route
router.get(
  "/admin-protectd",
  userAuth,
  checkRole(["admin"]),
  async (req, res) => {
    return res.json("Hello Admin");
  }
);

// Super Admin Protected Route
router.get(
  "/super-admin-protectd",
  userAuth,
  checkRole(["superadmin"]),
  async (req, res) => {
    return res.json("Hello Super Admin");
  }
);

// Super Admin Protected Route
router.get(
  "/super-admin-and-admin-protectd",
  userAuth,
  checkRole(["superadmin", "admin"]),
  async (req, res) => {
    return res.json("Super admin and Admin");
  }
);

router.get('/getUser', async (req, res) => {
  await getUser(res)
})
router.post('/deleteUser', async (req, res) => {
  await deleteUser(req, res)
})

router.get('/getDriver', async (req, res) => {
  await getDriver(res)
})
router.post('/deletDriver', async (req, res) => {
  await deleteDriver(req, res)
})

router.post('/showNearByCars', async (req, res) => {
  await showNearByCars(req, res)
})

router.post('/book', async (req, res) => {
  await book(req, res)
})

router.get('/getDriver', (req, res) => {
  driver.find((err, docs) => {
    if (docs.length > 0) {
      res.json({
        message: "All Drivers",
        success: true,
        data: docs
      })
    }
    else {
      res.json({
        message: "No Drivers.",
        success: false
      })
    }
  })
})

router.post('/addMyRides', async (req, res) => {
  var driverDetail;
  await driver.find({ _id: req.body.driverId }, (err, docs) => {
    driverDetail = docs[0]
  })

  //console.log(driverDetail)
  newRideBooking = {
    phone: req.body.phone,
    myrides: [{
      driverName: driverDetail.name,
      phone: driverDetail.phone,
      vehicle_name: driverDetail.vehicle_name,
      Vehicle_Registration_Number: driverDetail.Vehicle_Registration_Number,
      profile_pic: driverDetail.profile_pic,
      driverlocation: driverDetail.location,
      source: req.body.source,
      destination: req.body.destination,
      fair: 400,
      date: today.toDateString(),
      bookingid: uuidv4(),
      status: "1"
    }]
  }


  userRides.find({ phone: req.body.phone }, (err, docs) => {
    if (docs.length == 0) {
      createNewRides(req, res, newRideBooking)
    }
    else if (docs.length > 0) {
      addToExistingBooking(req, res, newRideBooking)
    }
    else {
      res.json({
        message: err,
        success: true
      })
    }

  })
})

const createNewRides = async (req, res, data) => {
  const newRide = new userRides(data)

  await newRide.save((err, docs) => {
    if (!err) {
      res.json({
        message: "Booking Successfull.",
        success: true,
        data: data.myrides[0]
      })
    }
    else {
      res.json({
        message: "Please Try Again.",
        success: false
      })
    }
  })
}


const addToExistingBooking = async (req, res, data) => {
  await userRides.findOneAndUpdate({ phone: req.body.phone }, {
    $push: {
      myrides: [...data.myrides]
    }
  }, (err, docs) => {
    if (!err) {
      res.json({
        message: "Booking Successfull.",
        success: true,
        data: data.myrides[0]
      })
    }
    else {
      res.json({
        message: "Please Try Again.",
        success: false
      })
    }
  })
}

router.post('/getMyRides', async (req, res) => {
  await userRides.findOne({ phone: req.body.phone }, (err, docs) => {
    if (!err) {
      res.json({
        message: "My Rides.",
        success: true,
        data: docs.myrides
      })
    }
    else {
      res.json({
        message: "Please Try Again.",
        success: false
      })
    }
  })
})

router.post('/cancelMyRide', async (req, res) => {
  await userRides.updateOne(
    { phone: req.body.phone },
    {
      $set:
      {
        'myrides.$[el].status': "2"
      }
    },
    {
      arrayFilters: [{ "el.bookingid": req.body.bookingid }],
      new: false
    },
    function (err, docs) {
      if (!err) {
        res.json({
          message: "Oreder Canceled.",
          success: true
        })
      }
      else {
        res.json({
          message: "Try Again Later.",
          success: false
        })
      }
    }
  );
})


router.post('/updateProfile', upload.single("vikash"), (req, res) => {
  //console.log(req.file)
  //profile_pic=String(req.protocol+"://"+req.hostname+":3000/"+req.file.destination+req.body.phone+".jpg")
  console.log(req.body.email, req.body.name, req.body.phone)
  fs.writeFile(`uploads/${req.body.phone}.jpg`, new Buffer.from(req.body.profile_pic, "base64"), function (err) { });
  profile_pic = String(req.protocol + "://" + req.hostname + ":4000/" + `uploads/${req.body.phone}.jpg`)
  User.findOneAndUpdate({ phone: req.body.phone }, { profile_pic: profile_pic, name: req.body.name, email: req.body.email }, (err, docs) => {
    if (!err) {
      res.send(docs)
    }
    else {
      res.status(201).json({
        message: `Error:- ${err}`,
        success: false,
      });
    }
  })
})

router.post('/notification', async (req, res) => {
  await notifications(req, res)
})

router.post('/getUserNotification', async (req, res) => {
  await getUserNotification(req, res)
})

router.post('/addfaq', (req, res) => {
  const fa = new faq({
    question: req.body.question,
    answer: req.body.answer
  })
  fa.save((err, docs) => {
    if (!err) {
      res.send("Faq Added")
    }
    else {
      res.send(err)
    }
  })
})

router.get('/getfaq', (req, res) => {
  faq.find((err, docs) => {
    if (!err) {
      res.send(docs)
    }
    else {
      res.send(err)
    }
  })
})

router.post('/resetPassword', async(req, res) => {
  const password = await bcrypt.hash(req.body.password, 12);
  User.findOneAndUpdate({ phone: req.body.phone },{password:password}, (err,docs)=> {
    if(!err){
      res.json({
        message:"New Password Set",
        success:true
      })
    }
    else{
      res.json({
        message:"Try Again Later",
        success:false
      })
    }
  })
})

router.post('/updateToken',(req,res)=>{
  token.find({phone:req.body.phone},(err,docs)=>{
    if(docs.length==0){
      const newToken=new token({
        phone:req.body.phone,
        token:req.body.token
      })

      newToken.save((err,docs)=>{
        if(!err){
          res.json({
            messageL:"Token Saved",
            success:true
          })
        }
        else{
          res.json({
            messageL:err,
            success:false
          })
        }
      })
    }
    else if(docs.length>0){
      token.findOneAndUpdate({phone:req.body.phone},{token:req.body.token},(err,obj)=>{
        if(!err){
          res.json({
            messageL:"New Tokrn Saved",
            success:true
          })
        }
        else{
          res.json({
            messageL:err,
            success:false
          })
        }
      })

    }
    else{

    }
  })
})


module.exports = router;
